import numpy as np
import tensorflow as tf
import os

from model import creer_reseaux, synchroniser_cible
from replay_buffer import ReplayBuffer
from environment import STATE_DIM



class AgentDoubleDQN:
    """
    Agent Double DQN avec experience replay et politique ε-greedy.

    Paramètres
    ----------
    action_dim        : borne max du nombre d'actions
    state_dim         : taille du vecteur d'état
    hidden_dims       : architecture des couches cachées
    lr                : taux d'apprentissage
    gamma             : facteur de dépréciation
    epsilon_debut     : ε initial (exploration pure)
    epsilon_fin       : ε minimal
    epsilon_decay     : facteur de décroissance multiplicatif par épisode
    buffer_capacite   : taille du replay buffer
    batch_size        : taille du mini-batch
    freq_mise_a_jour  : fréquence (en steps) de mise à jour du réseau principal
    freq_sync_cible   : fréquence (en steps) de synchronisation réseau cible
    tau               : coefficient de soft update (1.0 = hard update)
    """

    def __init__(
        self,
        action_dim=100,
        state_dim=STATE_DIM,
        hidden_dims=(256, 256, 128),
        lr=1e-3,
        gamma=0.99,
        epsilon_debut=1.0,
        epsilon_fin=0.05,
        epsilon_decay=0.995,
        buffer_capacite=50_000,
        batch_size=64,
        freq_mise_a_jour=4,
        freq_sync_cible=500,
        tau=1.0,
    ):
        self.action_dim       = action_dim
        self.gamma            = gamma
        self.epsilon          = epsilon_debut
        self.epsilon_fin      = epsilon_fin
        self.epsilon_decay    = epsilon_decay
        self.batch_size       = batch_size
        self.freq_mise_a_jour = freq_mise_a_jour
        self.freq_sync_cible  = freq_sync_cible
        self.tau              = tau

        # Réseaux principal et cible
        self.principal, self.cible = creer_reseaux(
            state_dim=state_dim,
            action_dim=action_dim,
            hidden_dims=hidden_dims,
        )

        # Optimiseur + loss
        self.optimiseur = tf.keras.optimizers.Adam(learning_rate=lr, clipnorm=10.0)
        self.perte_fn   = tf.keras.losses.Huber()

        # Replay buffer
        self.buffer = ReplayBuffer(capacite=buffer_capacite, state_dim=state_dim)

        # Compteurs
        self.total_steps   = 0
        self.total_updates = 0
        self.pertes        = []

    # ------------------------------------------------------------------
    # Sélection d'action
    # ------------------------------------------------------------------

    def choisir_action(self, etat, n_actions_valides):
        """
        Politique ε-greedy avec masquage des actions invalides.

        Paramètres
        ----------
        etat              : np.array de taille (state_dim,)
        n_actions_valides : nombre d'actions légales dans l'état courant

        Retourne l'indice de l'action choisie dans [0, n_actions_valides[
        """
        if n_actions_valides == 0:
            return 0

        # Exploration aléatoire
        if np.random.rand() < self.epsilon:
            return np.random.randint(0, n_actions_valides)

        # Exploitation : Q-values du réseau principal
        etat_t = etat[np.newaxis, :]                          # (1, state_dim)
        q_values = self.principal(etat_t, training=False)     # (1, action_dim)
        q_values = q_values.numpy()[0]                        # (action_dim,)

        # Masquer les actions hors bornes
        q_values_valides = q_values[:n_actions_valides]
        return int(np.argmax(q_values_valides))

    # ------------------------------------------------------------------
    # Stockage de transition
    # ------------------------------------------------------------------

    def memoriser(self, etat, action, recompense, etat_suiv, termine):
        self.buffer.ajouter(etat, action, recompense, etat_suiv, termine)
        self.total_steps += 1

    # ------------------------------------------------------------------
    # Mise à jour Double DQN
    # ------------------------------------------------------------------

    @tf.function  # compilation en graphe pour accélérer
    def _step_gradient(self, etats, actions, recompenses, etats_suiv, termines):
        """Calcule la perte et applique un pas de gradient."""

        # --- Cibles Double DQN (sans gradient) ---
        q_suiv_principal = self.principal(etats_suiv, training=False)
        meilleures_actions = tf.argmax(q_suiv_principal, axis=1)  # (batch,)

        q_suiv_cible = self.cible(etats_suiv, training=False)
        # Récupère Q_cible(s', a*) pour chaque exemple du batch
        indices_batch = tf.range(tf.shape(etats_suiv)[0], dtype=tf.int64)
        indices_2d = tf.stack([indices_batch, meilleures_actions], axis=1)
        q_suiv = tf.gather_nd(q_suiv_cible, indices_2d)           # (batch,)

        cibles = recompenses + self.gamma * q_suiv * (1.0 - termines)  # (batch,)

        # --- Perte sur le réseau principal ---
        with tf.GradientTape() as tape:
            q_actuelles = self.principal(etats, training=True)    # (batch, action_dim)

            # Sélectionne Q(s, a) pour l'action effectivement prise
            actions_64 = tf.cast(actions, tf.int64)
            indices_actions = tf.stack(
                [tf.cast(indices_batch, tf.int64), actions_64], axis=1
            )
            q_action = tf.gather_nd(q_actuelles, indices_actions) # (batch,)

            perte = self.perte_fn(cibles, q_action)

        gradients = tape.gradient(perte, self.principal.trainable_variables)
        self.optimiseur.apply_gradients(
            zip(gradients, self.principal.trainable_variables)
        )

        return perte

    def mettre_a_jour(self):
        """
        Effectue une étape de mise à jour si les conditions sont remplies.
        Retourne la valeur de la perte, ou None si pas de mise à jour.
        """
        if not self.buffer.est_pret(self.batch_size):
            return None
        if self.total_steps % self.freq_mise_a_jour != 0:
            return None

        etats, actions, recompenses, etats_suiv, termines = \
            self.buffer.echantillon(self.batch_size)

        # Conversion numpy → tenseurs TF
        etats       = tf.constant(etats,       dtype=tf.float32)
        actions     = tf.constant(actions,     dtype=tf.int64)
        recompenses = tf.constant(recompenses, dtype=tf.float32)
        etats_suiv  = tf.constant(etats_suiv,  dtype=tf.float32)
        termines    = tf.constant(termines,    dtype=tf.float32)

        perte = self._step_gradient(etats, actions, recompenses, etats_suiv, termines)
        perte_val = float(perte.numpy())

        self.total_updates += 1
        self.pertes.append(perte_val)

        # Synchronisation périodique du réseau cible
        if self.total_steps % self.freq_sync_cible == 0:
            synchroniser_cible(self.principal, self.cible, tau=self.tau)

        return perte_val

    # ------------------------------------------------------------------
    # Décroissance de ε
    # ------------------------------------------------------------------

    def decroitre_epsilon(self):
        self.epsilon = max(self.epsilon_fin, self.epsilon - (1.0 - self.epsilon_fin) / 100_000)

    # ------------------------------------------------------------------
    # Sauvegarde / chargement
    # ------------------------------------------------------------------

    def sauvegarder(self, chemin):
        """Sauvegarde les poids du réseau principal (format .weights.h5)."""
        os.makedirs(os.path.dirname(chemin) or '.', exist_ok=True)
        self.principal.save_weights(chemin + "_principal.weights.h5")
        self.cible.save_weights(chemin + "_cible.weights.h5")
        # Sauvegarde de l'état de l'agent
        np.save(chemin + "_meta.npy", {
            'epsilon':     self.epsilon,
            'total_steps': self.total_steps,
        })
        print(f"[Agent] Modèle sauvegardé → {chemin}")

    def charger(self, chemin):
        """Charge les poids depuis des fichiers .weights.h5."""
        self.principal.load_weights(chemin + "_principal.weights.h5")
        self.cible.load_weights(chemin + "_cible.weights.h5")
        meta = np.load(chemin + "_meta.npy", allow_pickle=True).item()
        self.epsilon     = meta['epsilon']
        self.total_steps = meta['total_steps']
        print(f"[Agent] Modèle chargé ← {chemin}")