"""
model.py
--------
Réseau de neurones MLP pour le Double DQN Rush Hour — TensorFlow/Keras.

Architecture :
    Entrée  : vecteur one-hot de taille STATE_DIM (684)
    Cachées : Dense → LayerNormalization → ReLU → Dropout (× n_couches)
    Sortie  : Dense → Q(s, a) pour chaque action possible

Le Double DQN utilise deux instances de ce réseau :
  - réseau principal (online)  : mis à jour à chaque batch
  - réseau cible    (target)   : copie périodique, utilisée pour les cibles Bellman
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from environment import STATE_DIM


def creer_reseau(state_dim=STATE_DIM, action_dim=100,
                 hidden_dims=(256, 256, 128), dropout=0.1):
    """
    Construit et retourne un modèle Keras MLP.

    Paramètres
    ----------
    state_dim   : taille du vecteur d'état en entrée
    action_dim  : nombre de Q-values en sortie (une par action possible)
    hidden_dims : tuple des tailles de couches cachées
    dropout     : taux de dropout

    Retourne
    --------
    keras.Model
    """
    entree = keras.Input(shape=(state_dim,), name="etat")
    x = entree

    for i, dim in enumerate(hidden_dims):
        x = layers.Dense(
            dim,
            kernel_initializer="glorot_uniform",
            bias_initializer="zeros",
            name=f"dense_{i}"
        )(x)
        x = layers.LayerNormalization(name=f"layernorm_{i}")(x)
        x = layers.ReLU(name=f"relu_{i}")(x)
        x = layers.Dropout(rate=dropout, name=f"dropout_{i}")(x)

    sortie = layers.Dense(
        action_dim,
        kernel_initializer="glorot_uniform",
        name="q_values"
    )(x)

    return keras.Model(inputs=entree, outputs=sortie)


def creer_reseaux(state_dim=STATE_DIM, action_dim=100,
                  hidden_dims=(256, 256, 128), dropout=0.1):
    """
    Crée le réseau principal et le réseau cible avec les mêmes poids initiaux.

    Retourne
    --------
    (principal, cible) : tuple de keras.Model
    """
    principal = creer_reseau(state_dim, action_dim, hidden_dims, dropout)
    cible     = creer_reseau(state_dim, action_dim, hidden_dims, dropout)

    # Synchronisation initiale : cible ← principal
    cible.set_weights(principal.get_weights())

    return principal, cible


def synchroniser_cible(principal, cible, tau=1.0):
    """
    Met à jour les poids du réseau cible.

    tau=1.0  → copie dure  : θ_cible ← θ_principal
    tau<1.0  → soft update : θ_cible ← τ·θ_principal + (1−τ)·θ_cible
    """
    if tau == 1.0:
        cible.set_weights(principal.get_weights())
    else:
        nouveaux_poids = [
            tau * p + (1.0 - tau) * c
            for p, c in zip(principal.get_weights(), cible.get_weights())
        ]
        cible.set_weights(nouveaux_poids)
