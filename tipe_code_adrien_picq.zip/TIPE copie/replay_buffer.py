"""
replay_buffer.py
----------------
Tampon d'expériences (Experience Replay) pour le Double DQN.
Stocke des transitions (s, a, r, s', done) et permet d'en
tirer des mini-batchs aléatoires pour l'entraînement.
Retourne des tableaux numpy (compatibles TensorFlow).
"""

import numpy as np


class ReplayBuffer:
    """
    Buffer circulaire FIFO de transitions.

    Paramètres
    ----------
    capacite  : nombre maximal de transitions stockées
    state_dim : taille du vecteur d'état
    """

    def __init__(self, capacite=50_000, state_dim=684):
        self.capacite  = capacite
        self.taille    = 0
        self.curseur   = 0

        # Pré-allocation numpy pour l'efficacité
        self.etats       = np.zeros((capacite, state_dim), dtype=np.float32)
        self.actions     = np.zeros(capacite, dtype=np.int32)
        self.recompenses = np.zeros(capacite, dtype=np.float32)
        self.etats_suiv  = np.zeros((capacite, state_dim), dtype=np.float32)
        self.termines    = np.zeros(capacite, dtype=np.float32)

    def ajouter(self, etat, action, recompense, etat_suiv, termine):
        """Enregistre une transition dans le buffer."""
        idx = self.curseur % self.capacite

        self.etats[idx]       = etat
        self.actions[idx]     = action
        self.recompenses[idx] = recompense
        self.etats_suiv[idx]  = etat_suiv
        self.termines[idx]    = float(termine)

        self.curseur += 1
        self.taille = min(self.taille + 1, self.capacite)

    def echantillon(self, batch_size):
        """
        Tire batch_size transitions aléatoirement.
        Retourne des tableaux numpy prêts pour TensorFlow.
        """
        indices = np.random.randint(0, self.taille, size=batch_size)

        return (
            self.etats[indices],
            self.actions[indices],
            self.recompenses[indices],
            self.etats_suiv[indices],
            self.termines[indices],
        )

    def est_pret(self, batch_size):
        return self.taille >= batch_size

    def __len__(self):
        return self.taille
