import argparse
import os
import time
import csv
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

from environment import RushHourEnv, _etat_vers_vecteur, _liste_deplacements
from agent import AgentDoubleDQN
from code_centrale import e_gagne, e_applique_deplacement


# ---------------------------------------------------------------------------
# Hyperparamètres par défaut
# ---------------------------------------------------------------------------

CONFIG = {
    # Environnement
    'n_perturbations':    3,
    'max_steps_episode':  150,

    # Entraînement
    'n_episodes':         3_000,
    'eval_freq':          100,    # évaluation tous les N épisodes
    'eval_episodes':      30,     # nb d'épisodes pour chaque évaluation
    'save_freq':          500,

    # Agent
    'action_dim':         180,
    'hidden_dims':        (256, 256, 128),
    'lr':                 1e-3,
    'gamma':              0.99,
    'epsilon_debut':      1.0,
    'epsilon_fin':        0.05,
    'epsilon_decay':      0.995,
    'buffer_capacite':    50_000,
    'batch_size':         64,
    'freq_mise_a_jour':   4,
    'freq_sync_cible':    1,
    'tau':                0.01,
}


# ---------------------------------------------------------------------------
# Fonctions utilitaires
# ---------------------------------------------------------------------------

def moyenne_mobile(valeurs, fenetre=50):
    """Calcule la moyenne mobile sur `fenetre` éléments."""
    if len(valeurs) < fenetre:
        return valeurs
    return np.convolve(valeurs, np.ones(fenetre) / fenetre, mode='valid')


def evaluer_agent(agent, env_eval, n_episodes=30):
    """
    Évalue l'agent en mode glouton (ε=0) sur n_episodes.

    Retourne
    --------
    taux_reussite  : float  — proportion d'épisodes gagnés
    reward_moyen   : float  — récompense moyenne
    steps_victoire : float  — nombre de coups moyen par victoire (nan si aucune)
    """
    epsilon_sauvegarde = agent.epsilon
    agent.epsilon = 0.0

    reussites = 0
    rewards_totaux = []
    steps_victoires = []

    for _ in range(n_episodes):
        etat = env_eval.reset()
        reward_total = 0.0
        done = False
        n_steps = 0

        while not done:
            n_actions = env_eval.nombre_actions_valides()
            action = agent.choisir_action(etat, n_actions)
            etat, reward, done, _ = env_eval.step(action)
            reward_total += reward
            n_steps += 1

        rewards_totaux.append(reward_total)
        if reward > 5.0:
            reussites += 1
            steps_victoires.append(n_steps)

    agent.epsilon = epsilon_sauvegarde
    moy_steps = np.mean(steps_victoires) if steps_victoires else float('nan')
    return reussites / n_episodes, np.mean(rewards_totaux), moy_steps


def evaluer_agent_inconnus(agent, puzzles_inconnus, max_steps, n_episodes=20):
    """
    Évalue l'agent sur des puzzles qu'il n'a jamais vus pendant l'entraînement.
    Simule directement les épisodes sans passer par RushHourEnv.

    Retourne
    --------
    float : taux de réussite sur les puzzles inconnus
    """
    from puzzles import puzzle_vers_etat

    epsilon_sauvegarde = agent.epsilon
    agent.epsilon = 0.0

    reussites = 0
    total = 0

    # Répartir les n_episodes sur tous les puzzles inconnus
    episodes_par_puzzle = max(1, n_episodes // len(puzzles_inconnus))

    for puzzle in puzzles_inconnus:
        for _ in range(episodes_par_puzzle):
            etat = puzzle_vers_etat(puzzle)
            state = _etat_vers_vecteur(etat)
            done = False
            steps = 0

            while not done and steps < max_steps:
                deplacements = _liste_deplacements(etat)
                n_actions = len(deplacements)
                if n_actions == 0:
                    break

                action_idx = agent.choisir_action(state, n_actions)
                action_idx = min(action_idx, n_actions - 1)
                etat = e_applique_deplacement(etat, deplacements[action_idx])
                state = _etat_vers_vecteur(etat)
                steps += 1

                if e_gagne(etat):
                    reussites += 1
                    done = True

            total += 1

    agent.epsilon = epsilon_sauvegarde
    return reussites / max(total, 1)


# ---------------------------------------------------------------------------
# Graphiques individuels (un seul mode)
# ---------------------------------------------------------------------------

def tracer_courbes(historique, mode, dossier_sortie):
    """
    Génère les 6 courbes d'apprentissage pour un seul mode d'entraînement.
    Sauvegarde dans dossier_sortie/courbes.png
    """
    fig, axes = plt.subplots(3, 2, figsize=(14, 16))
    fig.suptitle(f"Double DQN — Rush Hour — mode : {mode}", fontsize=14, fontweight='bold')

    episodes  = historique['episodes']
    eval_eps  = historique['eval_episodes']

    # ------------------------------------------------------------------
    # 1. Récompense par épisode (entraînement)
    # ------------------------------------------------------------------
    ax = axes[0, 0]
    ax.plot(episodes, historique['rewards'],
            alpha=0.3, color='steelblue', label='reward brut')
    mm = moyenne_mobile(historique['rewards'])
    ax.plot(episodes[len(episodes) - len(mm):], mm,
            color='steelblue', linewidth=2, label='moy. mobile (50)')
    ax.set_title("Récompense par épisode (entraînement)")
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Récompense totale")
    ax.legend()
    ax.grid(True, alpha=0.3)

    # ------------------------------------------------------------------
    # 2. Taux de réussite greedy sur puzzle de référence
    # ------------------------------------------------------------------
    ax = axes[0, 1]
    ax.plot(eval_eps, historique['taux_reussite'],
            color='seagreen', marker='o', markersize=4, linewidth=2)
    ax.set_title("Taux de réussite — puzzle de référence (greedy)")
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Taux de réussite")
    ax.set_ylim(0, 1.05)
    ax.axhline(y=0.9, color='red', linestyle='--', alpha=0.5, label='seuil 90%')
    ax.legend()
    ax.grid(True, alpha=0.3)

    # ------------------------------------------------------------------
    # 3. Gap train/eval — indicateur de surapprentissage
    # ------------------------------------------------------------------
    ax = axes[1, 0]
    gap = historique['gap_train_eval']
    ax.plot(eval_eps, gap, color='orangered', linewidth=2,
            marker='s', markersize=3, label='gap')
    ax.axhline(y=0, color='black', linestyle='--', alpha=0.4)
    ax.fill_between(eval_eps, gap, 0,
                    where=[g > 0 for g in gap],
                    alpha=0.2, color='red', label='surapprentissage')
    ax.fill_between(eval_eps, gap, 0,
                    where=[g <= 0 for g in gap],
                    alpha=0.2, color='green', label='bonne généralisation')
    ax.set_title("Gap train/eval — détection du surapprentissage")
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Récompense train − Récompense eval")
    ax.legend()
    ax.grid(True, alpha=0.3)

    # ------------------------------------------------------------------
    # 4. Taux de réussite sur puzzles inconnus
    # ------------------------------------------------------------------
    ax = axes[1, 1]
    taux_inc = historique.get('taux_inconnus', [])
    if taux_inc:
        step    = 500
        eps_inc = list(range(step, step * (len(taux_inc) + 1), step))
        ax.plot(eps_inc[:len(taux_inc)], taux_inc,
                color='purple', marker='^', markersize=5, linewidth=2,
                label='puzzles inconnus')
        ax.axhline(y=0.5, color='orange', linestyle='--',
                   alpha=0.5, label='seuil 50%')
        ax.set_ylim(0, 1.05)
        ax.legend()
    else:
        ax.text(0.5, 0.5, "Pas encore de données",
                ha='center', va='center', transform=ax.transAxes,
                fontsize=10, color='gray')
    ax.set_title("Taux de réussite — puzzles inconnus (généralisation)")
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Taux de réussite")
    ax.grid(True, alpha=0.3)

    # ------------------------------------------------------------------
    # 5. Steps moyens par victoire (efficacité)
    # ------------------------------------------------------------------
    ax = axes[2, 0]
    steps_v = historique.get('steps_victoire', [])
    valeurs_valides = [(eval_eps[i], s) for i, s in enumerate(steps_v)
                       if not np.isnan(s)]
    if valeurs_valides:
        eps_sv, sv = zip(*valeurs_valides)
        ax.plot(eps_sv, sv, color='teal', marker='D',
                markersize=3, linewidth=2, alpha=0.6, label='steps brut')
        mm_sv = moyenne_mobile(list(sv), fenetre=min(10, len(sv)))
        ax.plot(list(eps_sv)[len(eps_sv) - len(mm_sv):], mm_sv,
                color='darkslategray', linewidth=2, label='moy. mobile')
        ax.legend()
    ax.set_title("Steps moyens par victoire (efficacité)")
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Nombre de coups")
    ax.grid(True, alpha=0.3)

    # ------------------------------------------------------------------
    # 6. Décroissance de ε
    # ------------------------------------------------------------------
    ax = axes[2, 1]
    ax.plot(episodes, historique['epsilons'], color='darkorchid', linewidth=2)
    ax.set_title("Décroissance de ε (exploration)")
    ax.set_xlabel("Épisode")
    ax.set_ylabel("ε")
    ax.set_ylim(0, 1.05)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    chemin = os.path.join(dossier_sortie, "courbes.png")
    plt.savefig(chemin, dpi=120)
    plt.close()
    print(f"[Train] Courbes sauvegardées → {chemin}")


# ---------------------------------------------------------------------------
# Graphique comparatif anti-surapprentissage (fixe vs aléatoire)
# ---------------------------------------------------------------------------

def comparer_courbes(hist_fixe, hist_aleatoire,
                     dossier_sortie='results/comparaison'):
    """
    Génère le graphique comparatif en 3 panneaux illustrant l'anti-surapprentissage.

    Panneau 1 : Taux de réussite sur puzzle de référence
    Panneau 2 : Gap train/eval (indicateur de surapprentissage)
    Panneau 3 : Taux de réussite sur puzzles inconnus (généralisation)
    """
    os.makedirs(dossier_sortie, exist_ok=True)

    fig, axes = plt.subplots(1, 3, figsize=(21, 6))
    fig.suptitle(
        "Comparaison fixe vs aléatoire — Analyse du surapprentissage",
        fontsize=15, fontweight='bold'
    )

    couleur_fixe      = 'steelblue'
    couleur_aleatoire = 'coral'

    eval_f = hist_fixe['eval_episodes']
    eval_a = hist_aleatoire['eval_episodes']

    # ------------------------------------------------------------------
    # Panneau 1 — Taux de réussite
    # ------------------------------------------------------------------
    ax = axes[0]
    ax.plot(eval_f, hist_fixe['taux_reussite'],
            color=couleur_fixe, marker='o', markersize=4,
            linewidth=2, label='Fixe')
    ax.plot(eval_a, hist_aleatoire['taux_reussite'],
            color=couleur_aleatoire, marker='s', markersize=4,
            linewidth=2, label='Aléatoire')
    ax.axhline(y=0.9, color='red', linestyle='--', alpha=0.4, label='seuil 90%')
    ax.set_title("① Taux de réussite\n(puzzle de référence)", fontsize=12)
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Taux de réussite")
    ax.set_ylim(0, 1.05)
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.annotate(
        "Un agent fixe converge plus vite\nmais risque de mémoriser\nsans comprendre",
        xy=(0.04, 0.96), xycoords='axes fraction',
        fontsize=8, color='gray', style='italic', va='top'
    )

    # ------------------------------------------------------------------
    # Panneau 2 — Gap train/eval
    # ------------------------------------------------------------------
    ax = axes[1]
    gap_f = hist_fixe['gap_train_eval']
    gap_a = hist_aleatoire['gap_train_eval']

    ax.plot(eval_f, gap_f, color=couleur_fixe, linewidth=2,
            marker='o', markersize=3, label='Fixe')
    ax.plot(eval_a, gap_a, color=couleur_aleatoire, linewidth=2,
            marker='s', markersize=3, label='Aléatoire')
    ax.axhline(y=0, color='black', linestyle='--', alpha=0.5, label='équilibre')

    ax.fill_between(eval_f, gap_f, 0,
                    where=[g > 0 for g in gap_f],
                    alpha=0.12, color=couleur_fixe)
    ax.fill_between(eval_a, gap_a, 0,
                    where=[g > 0 for g in gap_a],
                    alpha=0.12, color=couleur_aleatoire)

    ax.set_title("② Gap train/eval\n(indicateur de surapprentissage)", fontsize=12)
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Récompense train − Récompense eval")
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.annotate(
        "Gap élevé = surapprentissage\nGap faible = bonne généralisation\n"
        "Zone colorée = amplitude du surapprentissage",
        xy=(0.04, 0.96), xycoords='axes fraction',
        fontsize=8, color='gray', style='italic', va='top'
    )

    # ------------------------------------------------------------------
    # Panneau 3 — Puzzles inconnus
    # ------------------------------------------------------------------
    ax = axes[2]
    inc_f = hist_fixe.get('taux_inconnus', [])
    inc_a = hist_aleatoire.get('taux_inconnus', [])

    if inc_f or inc_a:
        step    = 500
        n_max   = max(
            max(eval_f, default=0),
            max(eval_a, default=0)
        )
        eps_inc = list(range(step, n_max + 1, step))

        if inc_f:
            ax.plot(eps_inc[:len(inc_f)], inc_f,
                    color=couleur_fixe, marker='o', markersize=6,
                    linewidth=2, label='Fixe')
        if inc_a:
            ax.plot(eps_inc[:len(inc_a)], inc_a,
                    color=couleur_aleatoire, marker='s', markersize=6,
                    linewidth=2, label='Aléatoire')

        ax.axhline(y=0.5, color='orange', linestyle='--',
                   alpha=0.5, label='seuil 50%')
        ax.set_ylim(0, 1.05)
        ax.legend()
    else:
        ax.text(0.5, 0.5,
                "Données non disponibles\n(lancer avec --mode les_deux)",
                ha='center', va='center', transform=ax.transAxes,
                fontsize=10, color='gray')

    ax.set_title("③ Taux de réussite\n(puzzles jamais vus — généralisation)",
                 fontsize=12)
    ax.set_xlabel("Épisode")
    ax.set_ylabel("Taux de réussite")
    ax.grid(True, alpha=0.3)
    ax.annotate(
        "Test clé : l'agent aléatoire\ndoit mieux généraliser\nsur des puzzles inconnus",
        xy=(0.04, 0.96), xycoords='axes fraction',
        fontsize=8, color='gray', style='italic', va='top'
    )

    plt.tight_layout()
    chemin = os.path.join(dossier_sortie, "comparaison_anti_surapprentissage.png")
    plt.savefig(chemin, dpi=150)
    plt.close()
    print(f"[Comparaison] Graphique → {chemin}")


# ---------------------------------------------------------------------------
# Export CSV
# ---------------------------------------------------------------------------

def sauvegarder_csv(historique, dossier_sortie):
    """Sauvegarde les métriques épisode par épisode dans un CSV."""
    chemin = os.path.join(dossier_sortie, "metriques.csv")
    with open(chemin, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['episode', 'reward', 'epsilon', 'n_steps'])
        for ep, r, eps, s in zip(
            historique['episodes'],
            historique['rewards'],
            historique['epsilons'],
            historique['steps_par_episode'],
        ):
            writer.writerow([ep, round(r, 4), round(eps, 4), s])
    print(f"[Train] Métriques CSV → {chemin}")


# ---------------------------------------------------------------------------
# Boucle principale d'entraînement
# ---------------------------------------------------------------------------

def entrainer(mode='fixe', config=None, dossier_sortie=None):
    """
    Entraîne un agent Double DQN en mode `mode`.

    Paramètres
    ----------
    mode           : 'fixe' | 'aleatoire'
    config         : dict de CONFIG (hyperparamètres)
    dossier_sortie : dossier de sauvegarde des résultats
    """
    if config is None:
        config = CONFIG.copy()

    if dossier_sortie is None:
        dossier_sortie = os.path.join("results", mode)
    os.makedirs(dossier_sortie, exist_ok=True)

    # Puzzles réservés exclusivement pour tester la généralisation
    # (jamais utilisés pendant l'entraînement)
    from puzzles import PUZZLE_BANK
    PUZZLES_INCONNUS = PUZZLE_BANK[31:] if len(PUZZLE_BANK) > 31 else []

    device = 'GPU' if tf.config.list_physical_devices('GPU') else 'CPU'
    print(f"\n{'='*60}")
    print(f"  Double DQN — Rush Hour")
    print(f"  Mode            : {mode}")
    print(f"  Device          : {device}")
    print(f"  Épisodes        : {config['n_episodes']}")
    print(f"  Puzzles inconnus: {len(PUZZLES_INCONNUS)}")
    print(f"{'='*60}\n")

    # ------------------------------------------------------------------
    # Environnements
    # ------------------------------------------------------------------
    env_train = RushHourEnv(
        mode=mode,
        n_perturbations=config['n_perturbations'],
        max_steps=config['max_steps_episode'],
    )
    # Évaluation toujours sur le puzzle 0 (référence fixe)
    env_eval = RushHourEnv(
        mode='fixe',
        max_steps=config['max_steps_episode'],
    )

    # ------------------------------------------------------------------
    # Agent
    # ------------------------------------------------------------------
    agent = AgentDoubleDQN(
        action_dim=config['action_dim'],
        hidden_dims=config['hidden_dims'],
        lr=config['lr'],
        gamma=config['gamma'],
        epsilon_debut=config['epsilon_debut'],
        epsilon_fin=config['epsilon_fin'],
        epsilon_decay=config['epsilon_decay'],
        buffer_capacite=config['buffer_capacite'],
        batch_size=config['batch_size'],
        freq_mise_a_jour=config['freq_mise_a_jour'],
        freq_sync_cible=config['freq_sync_cible'],
        tau=config['tau'],
    )

    # ------------------------------------------------------------------
    # Historique des métriques
    # ------------------------------------------------------------------
    historique = {
        'episodes':          [],
        'rewards':           [],
        'epsilons':          [],
        'steps_par_episode': [],
        'pertes':            [],
        # --- métriques d'évaluation ---
        'eval_episodes':     [],
        'taux_reussite':     [],
        'reward_eval_moy':   [],
        # --- métriques anti-surapprentissage ---
        'gap_train_eval':    [],   # écart récompense train vs eval
        'taux_inconnus':     [],   # généralisation sur puzzles jamais vus
        'steps_victoire':    [],   # efficacité : coups moyens par victoire
    }

    debut = time.time()

    # ------------------------------------------------------------------
    # Boucle d'entraînement
    # ------------------------------------------------------------------
    for episode in range(1, config['n_episodes'] + 1):

        # Curriculum learning : augmente la difficulté progressivement
        if episode < 500:
            env_train.n_perturbations = 0
        elif episode < 1500:
            env_train.n_perturbations = 2
        else:
            env_train.n_perturbations = 5

        etat         = env_train.reset()
        reward_total = 0.0
        done         = False
        n_steps      = 0

        while not done:
            n_actions             = env_train.nombre_actions_valides()
            action                = agent.choisir_action(etat, n_actions)
            etat_suiv, reward, done, _ = env_train.step(action)

            agent.memoriser(etat, action, reward, etat_suiv, done)
            perte = agent.mettre_a_jour()

            if perte is not None:
                historique['pertes'].append(perte)

            etat          = etat_suiv
            reward_total += reward
            n_steps      += 1

        agent.decroitre_epsilon()

        historique['episodes'].append(episode)
        historique['rewards'].append(reward_total)
        historique['epsilons'].append(agent.epsilon)
        historique['steps_par_episode'].append(n_steps)

        # --- Affichage console toutes les 100 épisodes ---
        if episode % 100 == 0:
            moy_reward = np.mean(historique['rewards'][-100:])
            elapsed    = time.time() - debut
            print(
                f"Ep {episode:5d}/{config['n_episodes']} | "
                f"Reward moy (100): {moy_reward:7.2f} | "
                f"ε: {agent.epsilon:.3f} | "
                f"Steps: {agent.total_steps:7d} | "
                f"Temps: {elapsed:.0f}s"
            )

        # --- Évaluation greedy toutes les eval_freq épisodes ---
        if episode % config['eval_freq'] == 0:
            taux, reward_eval, moy_steps = evaluer_agent(
                agent, env_eval, config['eval_episodes']
            )
            historique['eval_episodes'].append(episode)
            historique['taux_reussite'].append(taux)
            historique['reward_eval_moy'].append(reward_eval)
            historique['steps_victoire'].append(moy_steps)

            moy_train = np.mean(historique['rewards'][-config['eval_freq']:])
            gap       = moy_train - reward_eval
            historique['gap_train_eval'].append(gap)

            # Évaluation sur puzzles inconnus tous les 500 épisodes
            if episode % 500 == 0 and PUZZLES_INCONNUS:
                taux_inc = evaluer_agent_inconnus(
                    agent,
                    PUZZLES_INCONNUS,
                    max_steps=config['max_steps_episode'],
                    n_episodes=20,
                )
                historique['taux_inconnus'].append(taux_inc)
                print(
                    f"  → Éval | Réussite : {taux*100:.1f}% | "
                    f"Reward : {reward_eval:.2f} | "
                    f"Gap : {gap:+.2f} | "
                    f"Inconnus : {taux_inc*100:.1f}% | "
                    f"Steps/victoire : {moy_steps:.1f}"
                )
            else:
                print(
                    f"  → Éval | Réussite : {taux*100:.1f}% | "
                    f"Reward : {reward_eval:.2f} | "
                    f"Gap : {gap:+.2f} | "
                    f"Steps/victoire : {moy_steps:.1f}"
                )

        # --- Sauvegarde périodique du modèle ---
        if episode % config['save_freq'] == 0:
            chemin_modele = os.path.join(dossier_sortie, f"modele_ep{episode}.pt")
            agent.sauvegarder(chemin_modele)

    # ------------------------------------------------------------------
    # Fin d'entraînement
    # ------------------------------------------------------------------
    agent.sauvegarder(os.path.join(dossier_sortie, "modele_final.pt"))
    tracer_courbes(historique, mode, dossier_sortie)
    sauvegarder_csv(historique, dossier_sortie)

    total = time.time() - debut
    print(f"\n[Train] Entraînement terminé en {total:.0f}s")
    print(f"[Train] Taux de réussite final : {historique['taux_reussite'][-1]*100:.1f}%")

    return historique


# ---------------------------------------------------------------------------
# Point d'entrée
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Entraînement Double DQN — Rush Hour"
    )
    parser.add_argument(
        '--mode', type=str, default='fixe',
        choices=['fixe', 'aleatoire', 'les_deux'],
        help="Mode d'environnement : fixe | aleatoire | les_deux"
    )
    parser.add_argument('--episodes', type=int, default=CONFIG['n_episodes'])
    parser.add_argument('--lr',       type=float, default=CONFIG['lr'])
    args = parser.parse_args()

    CONFIG['n_episodes'] = args.episodes
    CONFIG['lr']         = args.lr

    if args.mode == 'les_deux':
        print(">>> Entraînement en environnement FIXE")
        hist_fixe = entrainer(
            mode='fixe',
            config=CONFIG.copy(),
            dossier_sortie='results/fixe'
        )

        print("\n>>> Entraînement en environnement ALÉATOIRE")
        hist_aleatoire = entrainer(
            mode='aleatoire',
            config=CONFIG.copy(),
            dossier_sortie='results/aleatoire'
        )

        comparer_courbes(hist_fixe, hist_aleatoire)

    else:
        entrainer(mode=args.mode, config=CONFIG.copy())