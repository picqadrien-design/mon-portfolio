# diagnostic.py
from puzzles import PUZZLE_BANK, est_placement_valide
from code_centrale import e_nouveau, e_ajoute_vehicule

for i, p in enumerate(PUZZLE_BANK):
    try:
        ok = est_placement_valide(p)
        if not ok:
            print(f"Puzzle {i} : INVALIDE (superposition ou hors grille)")
        else:
            print(f"Puzzle {i} : OK")
    except Exception as ex:
        print(f"Puzzle {i} : ERREUR — {ex}")