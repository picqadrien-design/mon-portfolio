from collections import deque

M = 6
MAX_V = (M*M)//2
S = 2
VIDE = -1


class Vehicule:
    def __init__(self, i, j, longueur, direction):
        self.i = i
        self.j = j
        self.longueur = longueur
        self.direction = direction


class Etat:
    def __init__(self):
        self.v = []
        self.n = 0
        self.distance = 0

class Plateau:
    def __init__(self):
        self.tab = [[VIDE for _ in range(M)] for _ in range(M)]


def e_nouveau():
    return Etat()


def e_egal(e1, e2):
    if e1.n != e2.n:
        return False
    for k in range(e1.n):
        v1 = e1.v[k]
        v2 = e2.v[k]
        if (v1.i != v2.i or v1.j != v2.j or
            v1.longueur != v2.longueur or
            v1.direction != v2.direction):
            return False
    return True


def e_ajoute_vehicule(i, j, longueur, direction, e):
    if e.n >= MAX_V:
        raise ValueError("Trop de véhicules")
    e.v.append(Vehicule(i, j, longueur, direction))
    e.n += 1


def p_etat(e):
    p = Plateau()
    for k in range(e.n):
        i = e.v[k].i
        j = e.v[k].j
        for _ in range(e.v[k].longueur):
            p.tab[i][j] = k
            if e.v[k].direction == 'H':
                j += 1
            else:
                i += 1
    return p


def affiche_etat(e):
    p = p_etat(e)
    for i in range(M):
        ligne = ""
        for j in range(M):
            if p.tab[i][j] == VIDE:
                ligne += " "
            else:
                ligne += str(p.tab[i][j])
        print(ligne)
    print()


class Deplacement:
    def __init__(self, k, pas, suivant=None):
        self.k = k
        self.pas = pas
        self.suivant = suivant


def d_cons(k, pas, lst):
    return Deplacement(k, pas, lst)


def e_deplacements(e):
    l = None
    p = p_etat(e)

    for k in range(e.n):
        v = e.v[k]
        pas = 0
        i, j = v.i, v.j

        while True:
            if v.direction == 'V' and i + v.longueur < M:
                if p.tab[i + v.longueur][j] == VIDE:
                    i += 1
                    pas += 1
                    l = d_cons(k, pas, l)
                else:
                    break
            elif v.direction == 'H' and j + v.longueur < M:
                if p.tab[i][j + v.longueur] == VIDE:
                    j += 1
                    pas += 1
                    l = d_cons(k, pas, l)
                else:
                    break
            else:
                break

        i, j = v.i, v.j
        pas = 0

        while True:
            if v.direction == 'V' and i > 0:
                if p.tab[i - 1][j] == VIDE:
                    i -= 1
                    pas -= 1
                    l = d_cons(k, pas, l)
                else:
                    break
            elif v.direction == 'H' and j > 0:
                if p.tab[i][j - 1] == VIDE:
                    j -= 1
                    pas -= 1
                    l = d_cons(k, pas, l)
                else:
                    break
            else:
                break

    return l


def e_hash(e):
    p = p_etat(e)
    h = 0
    puiss3 = 1

    for i in range(M):
        for j in range(M):
            if p.tab[i][j] == -1:
                val = 0
            else:
                v = e.v[p.tab[i][j]]
                val = 1 if v.direction == 'H' else 2

            h += val * puiss3
            puiss3 *= 3

    return h


def e_gagne(e):
    for v in e.v:
        if v.direction == 'H' and v.i == S:
            return v.j == M-2
    return False


def e_applique_deplacement(e, d):
    e_suiv = e_nouveau()
    e_suiv.v = [Vehicule(v.i, v.j, v.longueur, v.direction) for v in e.v]
    e_suiv.n = e.n
    e_suiv.distance = e.distance

    v = e_suiv.v[d.k]

    if v.direction == 'H':
        v.j += d.pas
    else:
        v.i += d.pas

    e_suiv.distance += 1
    return e_suiv


def resout(e):
    f = deque()
    vus = set()

    f.append(e)

    while f:
        e_actuel = f.popleft()

        if e_gagne(e_actuel):
            print("Etat gagnant :")
            affiche_etat(e_actuel)
            return e_actuel.distance

        d = e_deplacements(e_actuel)
        curseur = d

        while curseur is not None:
            n_etat = e_applique_deplacement(e_actuel, curseur)
            h = e_hash(n_etat)

            if h not in vus:
                vus.add(h)
                f.append(n_etat)

            curseur = curseur.suivant

    return -1


if __name__ == "__main__":
    e_exemple = e_nouveau()

    e_ajoute_vehicule(0,4,2,'H', e_exemple)
    e_ajoute_vehicule(0,2,3,'V', e_exemple)
    e_ajoute_vehicule(2,0,2,'H', e_exemple)
    e_ajoute_vehicule(3,0,3,'H', e_exemple)
    e_ajoute_vehicule(3,5,3,'V', e_exemple)

    print("Nombre minimal de déplacements :", resout(e_exemple))