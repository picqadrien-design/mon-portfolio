"""
puzzles.py
----------
Banque de puzzles Rush Hour et utilitaires de randomisation.

Chaque puzzle est une liste de tuples (i, j, longueur, direction).
Convention : le véhicule 0 est TOUJOURS la voiture rouge (direction='H', ligne 2).

Niveaux :
    Puzzle   0      : exemple original
    Puzzles  1-10   : Beginner
    Puzzles 11-20   : Intermediate
    Puzzles 21-30   : Advanced
    Puzzles 31-40   : Expert

Tous les puzzles ont été validés (aucune superposition, aucun débordement).
"""

import random
from code_centrale import (
    e_nouveau, e_ajoute_vehicule, e_gagne,
    e_deplacements, e_applique_deplacement,
    M, S
)

PUZZLE_BANK = [
    [(2,0,2,'H'),(0,4,2,'H'),(0,2,3,'V'),(3,0,2,'H'),(3,5,3,'V')],                                                                                                 #  0 — exemple original
    [(2,0,2,'H'),(0,2,3,'V'),(0,4,2,'H'),(3,0,3,'H'),(3,5,3,'V')],                                                                                                 #  1 — Beginner
    [(2,2,2,'H'),(0,1,3,'V'),(3,0,3,'H'),(1,4,3,'V'),(4,2,2,'V'),(4,3,2,'H')],                                                                                     #  2 — Beginner
    [(2,0,2,'H'),(0,0,2,'H'),(0,2,2,'H'),(0,4,2,'H'),(1,1,2,'H'),(1,3,2,'H'),(2,2,2,'V'),(2,3,3,'V'),(4,2,2,'V'),(3,4,2,'H')],                                     #  3 — Beginner
    [(2,0,2,'H'),(1,2,2,'V'),(1,3,3,'V'),(2,4,2,'V'),(3,0,3,'H'),(4,0,2,'H'),(4,2,2,'H'),(4,4,2,'H')],                                                             #  4 — Beginner
    [(2,0,2,'H'),(0,1,3,'H'),(1,0,3,'H'),(3,0,3,'H'),(1,3,3,'V'),(3,4,2,'H'),(4,4,2,'H'),(4,3,2,'V'),(4,0,2,'V')],                                                 #  5 — Beginner
    [(2,0,2,'H'),(1,2,3,'V'),(1,4,2,'H'),(3,0,2,'V'),(4,1,2,'H'),(3,3,2,'H'),(4,4,2,'H'),(5,0,3,'H')],                                                             #  6 — Beginner
    [(2,1,2,'H'),(0,2,2,'H'),(0,4,3,'V'),(1,0,3,'H'),(3,1,3,'H'),(4,2,2,'V'),(5,3,2,'H')],                                                                         #  7 — Beginner
    [(2,2,2,'H'),(0,0,2,'H'),(0,3,2,'H'),(1,0,2,'H'),(1,3,2,'H'),(2,4,2,'H'),(2,1,3,'V'),(4,2,3,'H')],                                                             #  8 — Beginner
    [(2,0,2,'H'),(0,0,2,'H'),(0,2,2,'H'),(0,4,2,'V'),(1,1,2,'H'),(3,0,2,'H'),(3,2,2,'H'),(2,4,2,'V'),(4,4,2,'V')],                                                 #  9 — Beginner
    [(2,2,2,'H'),(0,1,3,'V'),(0,2,2,'H'),(0,4,2,'H'),(2,4,2,'H'),(3,1,2,'V'),(3,3,2,'V'),(3,4,2,'H'),(5,1,3,'H'),(5,4,2,'H')],                                     # 10 — Beginner
    
    [(2,0,2,'H'),(0,0,3,'H'),(0,3,2,'V'),(0,4,2,'V'),(1,2,2,'V'),(2,3,2,'H'),(2,5,2,'V'),(3,0,3,'H'),(4,3,2,'H'),(5,2,2,'H')],                                     # 11 — Intermediate
    [(2,1,2,'H'),(0,0,2,'H'),(0,2,2,'V'),(0,3,3,'V'),(0,4,3,'V'),(1,0,2,'V'),(2,5,3,'V'),(4,1,2,'V'),(4,2,2,'H'),(5,2,3,'H')],                                     # 12 — Intermediate
    [(2,0,2,'H'),(0,1,2,'H'),(0,4,2,'H'),(1,0,3,'H'),(1,3,3,'H'),(2,4,3,'V'),(3,0,2,'V'),(3,2,2,'H'),(3,5,3,'V'),(5,0,2,'H'),(5,2,3,'H')],                         # 13 — Intermediate
    [(2,1,2,'H'),(0,0,2,'H'),(0,2,2,'V'),(1,3,3,'H'),(2,3,2,'V'),(4,0,2,'H'),(4,2,3,'H'),(4,5,2,'V')],                                                             # 14 — Intermediate
    [(2,1,2,'H'),(0,0,3,'V'),(0,1,2,'H'),(0,3,2,'H'),(1,2,3,'H'),(2,4,2,'V'),(4,0,3,'H'),(5,0,3,'H'),(4,4,2,'H'),(5,4,2,'H')],                                     # 15 — Intermediate
    [(2,0,2,'H'),(0,3,2,'V'),(0,4,2,'V'),(2,2,2,'H'),(2,5,2,'V'),(3,1,2,'H'),(4,0,3,'H'),(4,3,2,'H'),(5,0,3,'H'),(5,4,2,'H')],                                     # 16 — Intermediate
    [(2,0,2,'H'),(0,0,3,'H'),(0,3,2,'H'),(1,0,2,'H'),(1,2,2,'H'),(1,4,3,'V'),(3,5,2,'V'),(4,1,2,'H'),(5,0,3,'H'),(5,4,2,'H')],                                     # 17 — Intermediate
    [(2,1,2,'H'),(0,1,2,'V'),(0,2,3,'H'),(2,3,2,'H'),(3,5,2,'V'),(3,0,2,'H'),(4,0,2,'H'),(3,2,3,'V'),(4,3,2,'H'),(5,3,3,'H')],                                     # 18 — Intermediate
    [(2,0,2,'H'),(0,1,2,'V'),(0,2,3,'H'),(1,4,2,'V'),(3,3,2,'V'),(4,4,2,'H'),(5,1,3,'H')],                                                                         # 19 — Intermediate
    [(2,0,2,'H'),(0,3,2,'V'),(0,4,2,'H'),(2,2,2,'H'),(2,4,2,'H'),(3,0,2,'V'),(4,1,3,'H'),(3,3,2,'H'),(4,4,2,'H')],                                                 # 20 — Intermediate
    
    [(2,1,2,'H'),(0,0,2,'H'),(0,2,2,'V'),(0,3,3,'V'),(1,0,3,'V'),(4,0,3,'H'),(3,3,3,'H'),(4,4,2,'V'),(5,2,2,'H')],                                                 # 21 — Advanced
    [(2,0,2,'H'),(0,1,2,'H'),(0,3,2,'H'),(1,2,2,'V'),(2,3,2,'H'),(2,5,3,'V'),(3,0,3,'V'),(5,1,3,'H'),(5,4,2,'H')],                                                 # 22 — Advanced
    [(2,1,2,'H'),(0,0,2,'V'),(0,2,2,'V'),(0,4,2,'H'),(1,3,3,'H'),(3,0,3,'V'),(3,1,2,'V'),(4,2,2,'H'),(5,1,2,'H'),(5,3,2,'H')],                                     # 23 — Advanced
    [(2,3,2,'H'),(0,0,3,'V'),(0,1,2,'V'),(1,2,2,'V'),(0,3,3,'H'),(3,0,2,'H'),(3,2,2,'H'),(3,5,3,'V'),(4,4,2,'V'),(5,1,2,'H')],                                     # 24 — Advanced
    [(2,1,2,'H'),(0,0,2,'H'),(0,3,3,'V'),(0,4,2,'H'),(2,0,2,'V'),(3,1,3,'H'),(2,4,3,'V'),(4,0,2,'V')],                                                             # 25 — Advanced
    [(2,1,2,'H'),(0,0,3,'V'),(0,2,2,'V'),(1,3,2,'H'),(2,3,2,'H'),(3,3,2,'H'),(3,1,3,'V'),(4,4,2,'H')],                                                             # 26 — Advanced
    [(2,1,2,'H'),(0,0,2,'H'),(0,2,2,'V'),(0,3,2,'H'),(1,0,3,'V'),(2,4,2,'V'),(3,1,3,'H'),(3,5,2,'V'),(4,4,2,'V')],                                                 # 27 — Advanced
    [(2,1,2,'H'),(0,1,3,'H'),(0,4,2,'V'),(1,2,2,'H'),(2,5,3,'V'),(3,0,2,'H'),(3,2,2,'H'),(4,1,2,'H'),(4,4,2,'V'),(5,2,2,'H')],                                     # 28 — Advanced
    [(2,2,2,'H'),(0,0,2,'H'),(0,2,2,'V'),(0,3,2,'V'),(0,4,3,'V'),(3,3,2,'H'),(4,0,2,'H'),(4,2,2,'H')],                                                             # 29 — Advanced
    [(2,0,2,'H'),(0,0,2,'V'),(0,2,3,'H'),(1,1,3,'H'),(1,4,3,'V'),(2,2,2,'H'),(3,0,2,'H'),(3,5,2,'V'),(4,2,2,'H'),(5,2,2,'H')],                                     # 30 — Advanced
    
    [(2,1,2,'H'),(0,0,2,'H'),(0,2,2,'V'),(0,3,2,'H'),(1,4,2,'H'),(3,0,3,'V'),(2,3,2,'H'),(3,1,2,'V'),(4,3,3,'H'),(5,2,3,'H')],                                     # 31 — Expert 
    [(2,1,2,'H'),(0,0,3,'H'),(0,4,3,'V'),(0,5,3,'V'),(1,0,2,'H'),(1,2,2,'H'),(3,0,2,'H'),(3,2,2,'H'),(4,1,2,'V'),(4,3,2,'H'),(5,2,2,'H'),(5,4,2,'H')],             # 32 — Expert 
    [(2,1,2,'H'),(0,0,2,'V'),(0,1,3,'H'),(0,4,2,'V'),(1,2,2,'H'),(2,4,2,'H'),(3,0,2,'H'),(3,2,2,'H'),(4,3,2,'V'),(4,0,2,'H'),(5,0,3,'H')],                         # 33 — Expert 
    [(2,0,2,'H'),(0,0,2,'H'),(0,3,3,'V'),(0,4,2,'V'),(1,2,2,'V'),(1,5,2,'V'),(3,0,2,'H'),(3,2,2,'H'),(3,4,2,'H'),(4,2,2,'V'),(4,4,2,'V'),(5,0,2,'H')],             # 34 — Expert 
    [(2,2,2,'H'),(0,0,2,'H'),(0,2,2,'V'),(0,4,2,'V'),(1,0,2,'V'),(1,1,2,'V'),(2,4,3,'V'),(3,0,3,'V'),(3,1,2,'H'),(4,2,2,'V'),(4,5,2,'V')],                         # 35 — Expert 
    [(2,1,2,'H'),(0,0,3,'V'),(0,1,2,'H'),(1,3,2,'V'),(1,4,2,'H'),(3,1,3,'V'),(4,2,2,'H'),(4,4,2,'H')],                                                             # 36 — Expert 
    [(2,1,2,'H'),(0,0,3,'H'),(0,4,3,'V'),(1,0,2,'V'),(1,1,2,'H'),(2,3,2,'V'),(3,2,2,'V'),(4,0,2,'H'),(4,3,2,'H'),(3,5,2,'V'),(5,2,2,'H')],                         # 37 — Expert 
    [(2,1,2,'H'),(0,0,3,'V'),(0,1,2,'H'),(0,3,2,'H'),(1,1,2,'H'),(1,3,2,'V'),(1,4,3,'V'),(3,0,3,'H'),(3,3,2,'V'),(4,0,2,'V'),(4,4,2,'H'),(5,1,2,'H'),(5,3,2,'H')], # 38 — Expert 
    [(2,1,2,'H'),(0,1,2,'V'),(0,3,3,'H'),(1,3,2,'V'),(1,4,2,'H'),(3,0,2,'V'),(2,4,3,'V'),(3,1,2,'V'),(4,2,2,'V'),(5,3,2,'H')],                                     # 39 — Expert 
    [(2,0,2,'H'),(0,0,2,'V'),(0,1,2,'H'),(0,3,3,'H'),(1,2,2,'V'),(1,3,2,'H'),(2,5,2,'V'),(3,0,2,'H'),(3,2,2,'H'),(4,1,2,'H'),(5,0,3,'H'),(3,4,3,'V')],             # 40 — Expert 
]


def puzzle_vers_etat(puzzle):
    """Construit un Etat à partir d'un puzzle (liste de tuples)."""
    e = e_nouveau()
    for (i, j, longueur, direction) in puzzle:
        e_ajoute_vehicule(i, j, longueur, direction, e)
    return e


def puzzle_aleatoire():
    """Retourne un puzzle aléatoire de la banque."""
    return random.choice(PUZZLE_BANK)


def est_placement_valide(puzzle):
    """Vérifie qu'aucun véhicule ne dépasse les bords ni ne se superpose."""
    grille = [[False] * M for _ in range(M)]
    for (i, j, longueur, direction) in puzzle:
        ci, cj = i, j
        for _ in range(longueur):
            if not (0 <= ci < M and 0 <= cj < M):
                return False
            if grille[ci][cj]:
                return False
            grille[ci][cj] = True
            if direction == 'H':
                cj += 1
            else:
                ci += 1
    return True


def perturber_puzzle(puzzle, n_perturbations=2):
    """
    Applique n_perturbations déplacements aléatoires valides à un puzzle.
    Retourne un nouveau puzzle (liste de tuples) après perturbation.
    """
    e = puzzle_vers_etat(puzzle)
    for _ in range(n_perturbations):
        deplacements = []
        d = e_deplacements(e)
        while d is not None:
            deplacements.append(d)
            d = d.suivant
        if not deplacements:
            break
        deplacements_sans_rouge = [d for d in deplacements if d.k != 0]
        candidats = deplacements_sans_rouge if deplacements_sans_rouge else deplacements
        choix = random.choice(candidats)
        e = e_applique_deplacement(e, choix)
        if e_gagne(e):
            e = e_applique_deplacement(
                e, type('D', (), {'k': choix.k, 'pas': -choix.pas})()
            )
    return [(v.i, v.j, v.longueur, v.direction) for v in e.v]


def echantillon_environnement(mode='fixe', puzzle_fixe=None, n_perturbations=2):
    """
    Retourne un état initial selon le mode :
      - 'fixe'      : toujours le même puzzle (puzzle_fixe ou puzzle 0)
      - 'banque'    : puzzle aléatoire parmi PUZZLE_BANK
      - 'perturbe'  : puzzle de la banque + perturbations aléatoires
      - 'aleatoire' : banque + perturbation (mode complet)
    """
    if mode == 'fixe':
        p = puzzle_fixe if puzzle_fixe is not None else PUZZLE_BANK[0]
        return puzzle_vers_etat(p)
    elif mode == 'banque':
        return puzzle_vers_etat(puzzle_aleatoire())
    elif mode == 'perturbe':
        p = puzzle_fixe if puzzle_fixe is not None else PUZZLE_BANK[0]
        return puzzle_vers_etat(perturber_puzzle(p, n_perturbations))
    elif mode == 'aleatoire':
        p = puzzle_aleatoire()
        return puzzle_vers_etat(perturber_puzzle(p, n_perturbations))
    else:
        raise ValueError(
            f"Mode inconnu : {mode}. Choisir parmi : fixe, banque, perturbe, aleatoire"
        )