"""
environment.py
--------------
Wrapper autour du simulateur Rush Hour.

Interface inspirée de Gym :
    env.reset()  → state (np.array)
    env.step(action_index) → (next_state, reward, done, info)
    env.action_space_size  → int

Encodage de l'état : one-hot par case de la grille
    Chaque case (i,j) est encodée par un vecteur de taille (MAX_VEHICULES + 1) :
      - Index 0        : case vide
      - Index k+1      : case occupée par le véhicule k
    Vecteur d'état final : 6×6×(MAX_VEHICULES+1) aplati → taille STATE_DIM

Récompense :
    +10.0  : victoire (voiture rouge sortie)
    -0.1   : pas ordinaire (pénalité légère pour encourager la concision)
    -1.0   : action invalide tentée (aucun déplacement possible ou index hors bornes)
    bonus  : −distance_rouge_sortie * 0.01 (reward shaping par proximité)
"""

import numpy as np
from code_centrale import (
    e_gagne, e_deplacements, e_applique_deplacement,
    p_etat, M, S, VIDE, MAX_V
)
from puzzles import echantillon_environnement

# Taille du vecteur one-hot par case : vide + jusqu'à MAX_V véhicules
ONE_HOT_SIZE = MAX_V + 1
STATE_DIM    = M * M * ONE_HOT_SIZE   # 6×6×19 = 684


def _etat_vers_vecteur(e):
    """
    Convertit un Etat en vecteur numpy one-hot.
    Shape : (M*M*ONE_HOT_SIZE,) = (684,)
    """
    plateau = p_etat(e)
    vec = np.zeros(M * M * ONE_HOT_SIZE, dtype=np.float32)

    for i in range(M):
        for j in range(M):
            case_idx = i * M + j
            occupant = plateau.tab[i][j]
            if occupant == VIDE:
                hot_idx = 0
            else:
                hot_idx = occupant + 1  # véhicule k → index k+1
            vec[case_idx * ONE_HOT_SIZE + hot_idx] = 1.0

    return vec


def _distance_rouge_sortie(e):
    """
    Distance (en cases) entre la tête droite de la voiture rouge et la sortie.
    Voiture rouge = véhicule 0, direction H, ligne S=2.
    Sortie = colonne M-1 (bord droit).
    """
    rouge = e.v[0]
    # Extrémité droite de la voiture rouge
    col_droite = rouge.j + rouge.longueur - 1
    return (M - 1) - col_droite


def _liste_deplacements(e):
    """Convertit la liste chaînée en liste Python."""
    deplacements = []
    d = e_deplacements(e)
    while d is not None:
        deplacements.append(d)
        d = d.suivant
    return deplacements


class RushHourEnv:
    """
    Environnement Rush Hour compatible avec une boucle RL standard.

    Paramètres
    ----------
    mode : str
        Mode de génération des puzzles à chaque reset().
        'fixe'      — toujours le même puzzle
        'banque'    — puzzle aléatoire de la banque
        'perturbe'  — puzzle fixe avec perturbations aléatoires
        'aleatoire' — banque + perturbations (randomisation maximale)
    puzzle_fixe : list | None
        Puzzle utilisé en mode 'fixe' ou 'perturbe'. Si None, puzzle 0.
    n_perturbations : int
        Nombre de déplacements aléatoires appliqués en mode perturbé.
    max_steps : int
        Nombre maximal de pas avant de terminer l'épisode (évite les boucles infinies).
    """

    def __init__(self, mode='fixe', puzzle_fixe=None,
                 n_perturbations=2, max_steps=200):
        self.mode = mode
        self.puzzle_fixe = puzzle_fixe
        self.n_perturbations = n_perturbations
        self.max_steps = max_steps

        self.etat = None
        self.steps = 0
        self._deplacements_cache = []  # liste des déplacements valides

        # Taille de l'espace d'état
        self.state_dim = STATE_DIM

        # On fixe une taille maximale d'espace d'action.
        # En pratique le nombre d'actions légales varie, mais le réseau
        # prédit une Q-value pour chaque indice de 0 à max_actions-1.
        # Les actions invalides sont masquées au moment de la sélection.
        self.max_actions = MAX_V * (M - 1) * 2  # borne large conservative

    # ------------------------------------------------------------------
    # Interface principale
    # ------------------------------------------------------------------

    def reset(self):
        """Réinitialise l'environnement et retourne l'état initial."""
        self.etat = echantillon_environnement(
            mode=self.mode,
            puzzle_fixe=self.puzzle_fixe,
            n_perturbations=self.n_perturbations,
        )
        self.steps = 0
        self._deplacements_cache = _liste_deplacements(self.etat)
        return _etat_vers_vecteur(self.etat)

    def step(self, action_index):
        """
        Applique l'action d'index action_index dans la liste des déplacements valides.

        Retourne
        --------
        next_state : np.array
        reward     : float
        done       : bool
        info       : dict
        """
        self.steps += 1

        # Action invalide (index hors bornes)
        if action_index < 0 or action_index >= len(self._deplacements_cache):
            next_state = _etat_vers_vecteur(self.etat)
            return next_state, -1.0, False, {'raison': 'action_invalide'}

        deplacement = self._deplacements_cache[action_index]
        nouvel_etat = e_applique_deplacement(self.etat, deplacement)

        self.etat = nouvel_etat
        self._deplacements_cache = _liste_deplacements(self.etat)

        next_state = _etat_vers_vecteur(self.etat)

        # --- Calcul de la récompense ---
        if e_gagne(self.etat):
            reward = 10.0
            done   = True
            info   = {'raison': 'victoire', 'steps': self.steps}

        elif self.steps >= self.max_steps:
            dist   = _distance_rouge_sortie(self.etat)
            reward = -0.1 - dist * 0.01
            done   = True
            info   = {'raison': 'timeout', 'steps': self.steps}

        else:
            dist   = _distance_rouge_sortie(self.etat)
            reward = -0.1 - dist * 0.01
            done   = False
            info   = {'raison': 'continuer', 'steps': self.steps}

        return next_state, reward, done, info

    def nombre_actions_valides(self):
        """Retourne le nombre d'actions légales dans l'état courant."""
        return len(self._deplacements_cache)

    def get_deplacements(self):
        """Retourne la liste des déplacements valides (pour debug/analyse)."""
        return self._deplacements_cache

    def render(self):
        """Affiche la grille dans le terminal."""
        from code_centrale import affiche_etat
        affiche_etat(self.etat)
